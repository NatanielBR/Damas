package damas;

import java.io.File;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;

/**
 * Classe responsavel por realizar o movimento entre duas Labels, esta tambem
 * realiza a marcação das Labels e a validação do movimento da mesma.
 *
 * @author Nataniel
 */
public class ADM {

    private LabelDetect lbdt;

    private Label lb1 = null;
    private Label lb1s = null;
    private Label lb2s = null;
    private Label lclick = null;
    private boolean p1sel = false;
    private boolean continuar = false;
    private boolean lbmarc = false;
    private boolean val = false;
    private File base;

    private Label lmov1;
    private double xm1 = 0;
    private double ym1 = 0;
    private Label lmov2;
    private Label lmov3;

    /**
     * Construtor que recebe a uma LabelDetect e um arquivo da base cinza. Ela
     * simplesmente "leva pra fora" das parametros para ser usado pelos metodos.
     *
     * @param lbd Eis uma LabelDetect, classe que recebe diversas labels que
     * internamente calcula qual Label é com base no click na panel.
     * Internamente, essa classe precisa dessa outra, para selecionar outras
     * labels e realizar o moviemento correto.
     * @param baseC Para realizar a troca do grafico entre duas labels é
     * nescessario ter um grafico "padrao",ou seja, a base cinza. Caso tenha
     * duvida analize o codigo.
     */
    public ADM(LabelDetect lbd, File baseC) {
        lbdt = lbd;
        base = baseC;
    }
    private double clicx;
    private double clicy;

    /**
     * Metodo que realiza a troca das pecas entre duas labels, considerando o
     * resultado do metodo privado movVal. Internamente, ele obtem a primeira
     * peça e dentro do mesmo metodo, ele obtem a segunda peca. Observe o codigo
     * para observar melhor como ele faz isso.
     *
     * @param x Valor do eixo X do click, o valor deve ser do click na pane e
     * nao do click na label.
     * @param y Valor do eixo Y do click, o valor deve ser do click na pane e
     * nao do click na label.
     */
    public void trocar(double x, double y) {
        clicx = x;
        clicy = y;
        lb1 = lbdt.clickXY(x, y);
        if (lb1.getProperties().get("p") != null) {
            this.movSel(lb1);

            if (lb1.getProperties().get("p").equals("cp2")) {

                lb1s = lb1;
                continuar = true;

            } else if (continuar) {
                continuar = false;
                if (this.movVal(lb1)) {
                    lb2s = lb1;
                    lb2s.setGraphic(lb1s.getGraphic());
                    lb1s.setGraphic(new ImageView(base.getPath()));
                    lb1s.setId("bt3");
                    lb2s.setId("bt3");
                    lb1s.getProperties().replace("p", "sp");
                    lb2s.getProperties().replace("p", "cp2");

                    if (lmov3 != null) {
                        lmov3.setId("bt3");
                        lmov2.setId("bt3");
                    } else if (lmov2 != null) {
                        lmov2.setId("bt3");
                    }
                    val = false;
                    lbmarc = false;

                } else {
                    lb1s.setId("bt3");
                    lb1.setId("bt3");
                    lb1s = null;
                    lbmarc = false;
                    this.desmarcarTudo();
                }
            }
        }
    }

    /**
     * metodo privado que ira selecionar os espaços disponives para o movimento,
     * essa metodo participa em conjunto com o movVal.
     *
     * @param a É nescessario informar a Label que ocorreu o click ( resultado
     * da LabelDetect), para poder calcular as pecas que irá ser marcada.
     */
    private void movSel(Label a) {
        if ((a.getProperties().get("p").equals("cp2"))) {
            if (!lbmarc) {
                lclick = a;
                lmov1 = a;
                xm1 = a.getLayoutX();
                ym1 = a.getLayoutY();
                lbmarc = true;
                if (xm1 == 0) {
                    lmov2 = lbdt.clickXY(xm1 + 70, ym1 - 70);
                    if (lmov2.getProperties().get("p").equals("sp")) {
                        lmov2.setId("btsel");
                    }
                } else {
                    lmov2 = lbdt.clickXY(xm1 - 70, ym1 - 70);
                    lmov3 = lbdt.clickXY(xm1 + 70, ym1 - 70);
                    if (lmov2.getProperties().get("p") != null) {
                        if (lmov2.getProperties().get("p").equals("sp")) {
                            lmov2.setId("btsel");
                        }
                    }
                    if (lmov3.getProperties().get("p") != null) {
                        if (lmov3.getProperties().get("p").equals("sp")) {
                            lmov3.setId("btsel");
                        }
                    }
                }
            } else if (a.getLayoutX() == xm1 && a.getLayoutY() == ym1) {
                a.setId("bt3");
                lbmarc = false;
                this.desmarcarTudo();
                continuar = false;
            } else if (lclick != null) {
                this.desmarcarTudo();
                a.setId("bt3");
                lclick.setId("bt3");
                lbmarc = false;
                continuar = false;
                lclick = null;
            }
        }
    }

    /**
     * Metodo privado para desmarcar todas as labels que foi marcada.
     */
    private void desmarcarTudo() {
        if (lmov3 != null) {
            lmov3.setId("bt3");
            lmov2.setId("bt3");
            lmov3 = null;
            lmov2 = null;
        } else if (lmov2 != null) {
            lmov2.setId("bt3");
            lmov2 = null;
        }
    }

    /**
     * Metodo privado que irá validar o movimento da Label. O primeiro passo é
     * verificar quantas pecas foi marcada. O segundo passo é descobrir se a
     * peca que foi clicada foi a marcada, isso é verificado usando o getId()
     * entre as Labels involvido.
     *
     * @param a
     * @return
     */
    private boolean movVal(Label a) {
        if (lmov3 != null) {
            if ((lmov3.getId().equals(a.getId())) || (lmov2.getId().equals(a.getId()))) {
                val = true;
            }
        } else if (lmov2 != null) {
            if (lmov2.getId().equals(a.getId())) {
                val = true;
            }
        }
        return val;
    }
}
