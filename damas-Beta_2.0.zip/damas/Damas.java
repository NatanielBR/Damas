package damas;
import java.io.IOException;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;

/**
 *Classe principal... bem nao tenho muita coisa para falar dela,
 * futuramente essa classe será mas complexa.
 * @author Criado por nataniel
 */
public class Damas extends Application{
    @Override
    public void start(Stage ps) throws IOException{
        GridPane pn=new GridPane();
        Cena1 c1=new Cena1();
        ps.setScene(new Cena1().getCena());
        ps.setResizable(false);
        ps.show();
    }
    public static void main(String[] args) {
        launch(args);
    }
    
}
