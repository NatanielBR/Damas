package damas;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import javafx.scene.control.Label;

/**
 * Essa classe foi a mas complicada e mas facil ao mesmo tempo,
 * ela e uma das mais importantes e é usada em toda a aplicação.
 * @author Administrator
 */
public class LabelDetect {
    private Label[] lbl=null;
    private int aux=0;
    private int tam=0;
    private int tam2=0;
    private double Lx=0;
    private double Ly=0;
    private double[] eixoX=null;
    private double[] eixoY=null;
    /**
     * Construtor irá ler o arquivo "cord.txt" e apos ler irá jogar
     * no array "eixoX" e o "eixoY".
     * @param a
     * Esse é uma array com todas as Labels que existe na pane.
     * @throws FileNotFoundException 
     * Caso não ache esse arquivo a aplicação não deve executar
     * por isso eu não quis tratar essa exception.
     */
    public LabelDetect(Label ... a) throws FileNotFoundException {
        Scanner ent=new Scanner(new FileReader("cord.txt"));
        lbl=a;
        tam=a.length;
        tam2=tam+1;
        eixoX=new double[tam];
        eixoY=new double[tam2];
        if(ent.next().equals("<cord>")){
            while(true){
                if(ent.next().equals("<x>")){
                    for(int i=0;i!=eixoX.length;i++){
                        eixoX[i]=Double.valueOf(ent.next());
                    }
                }
                if(ent.next().equals("</x>")){
                    break;
                }
            }
            while(true){
                if (ent.next().equals("<y>")){
                   for(int i=0;i!=eixoY.length;i++){
                       eixoY[i]=Double.valueOf(ent.next());
                   }
                }
                if(ent.next().equals("</y>")){
                    break;
                }
            }   
        }
        if(ent.next().equals("</cord>")){
            ent.close();
        }
        }
    /**
     * Esse metodo irá retornar o eixo X do click na pane.
     * @param x
     * Valor do click na pane.
     * @return 
     * Valor X da Label Clicada.
     */
    public double clickX(double x){
        for(double i : eixoX){
            if(i>x){
                Lx=i;
                break;
            }
        }
        return Lx-70;
    }
    /**
     * Esse metodo irá retornar o eixo Y do click na pane.
     * @param y
     * Valor do click na pane.
     * @return 
     * Valor Y da Label Clicada.
     */
    public double clickY(double y){
        for(double i : eixoY){
            if(i>y){
                Ly=i;
                break;
            }
        }
        return Ly-70;
    }
    /**
     * Caso queira obter a label e nao a coordenada dela,
     * use esse metodo. Ele irá usar, internamente os dois metodos
     * acima para poder escolher a label.
     * @param x
     * Valor do eixo X no click na pane
     * @param y
     * Valor do eixo Y no click na pane
     * @return 
     * retorna a Label que corresponde ao click X eY.
     */
    public Label clickXY(double x,double y){
        Lx=clickX(x);
        Ly=clickY(y);
        Label a=null;
        for(int i=0;i!=lbl.length;i++){
            if((lbl[i].getLayoutX()==Lx)&&(lbl[i].getLayoutY()==Ly)){
                a=lbl[i];
            }
        }
        return a;
    }
}
