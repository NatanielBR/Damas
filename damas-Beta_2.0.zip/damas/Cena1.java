package damas;
import java.io.File;
import java.io.IOException;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
/**
 * Essa classe foi criada com o intuido de resolver um problema, porem
 * a solução desse problema não exigiu a criação da mesma.
 * Mantive essa classe por que ela não me trouxe problema nenhum.
 * @author Nataniel
 */
public class Cena1 {
    private Scene a=null;
    private final Label lb=new Label();
    private Label lb1=new Label();
    private Label lb2=new Label();
    private Label lb3=new Label();
    private Label lb4=new Label();
    private Label lb5=new Label();
    private Label lb6=new Label();
    private Label lb7=new Label();
    private Label lb8=new Label();
    private Label lb9=new Label();
    private Label lb10=new Label();
    private Label lb11=new Label();
    private Label lb12=new Label();
    private Label lb13=new Label();
    private Label lb14=new Label();
    private Label lb15=new Label();
    private Label lb16=new Label();
    private Label lb17=new Label();
    private Label lb18=new Label();
    private Label lb19=new Label();
    private Label lb20=new Label();
    private Label lb21=new Label();
    private Label lb22=new Label();
    private Label lb23=new Label();
    private Label lb24=new Label();
    private Label lb25=new Label();
    private Label lb26=new Label();
    private Label lb27=new Label();
    private Label lb28=new Label();
    private Label lb29=new Label();
    private Label lb30=new Label();
    private Label lb31=new Label();
    private Label lb32=new Label();
    private Label lb33=new Label();
    private Label lb34=new Label();
    private Label lb35=new Label();
    private Label lb36=new Label();
    private Label lb37=new Label();
    private Label lb38=new Label();
    private Label lb39=new Label();
    private Label lb40=new Label();
    private Label lb41=new Label();
    private Label lb42=new Label();
    private Label lb43=new Label();
    private Label lb44=new Label();
    private Label lb45=new Label();
    private Label lb46=new Label();
    private Label lb47=new Label();
        
    private boolean ativou=false;
    
    public Cena1() throws IOException {
        GridPane pn=new GridPane();
        LabelDetect dt=new LabelDetect(lb,lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lb9,lb10,lb11,lb12,lb13,lb14,lb15,lb16,lb17,lb18,lb19,lb20,lb21,lb22,lb23,lb24,lb25,lb26,lb27,lb28,lb29,lb30,lb31,lb32,lb33,lb34,lb,lb35,lb36,lb37,lb38,lb39,lb40,lb41,lb42,lb43,lb44,lb45,lb46,lb47);
        a=new Scene(pn,418,558);
        
        a.getStylesheets().add("damas/css/root.css");
        a.getStylesheets().add("damas/css/botao.css");
        
        
        File ib=new File("damas/res/baseB.png");
        File ic=new File("damas/res/baseC.png");
        File p1=new File("damas/res/pe1.png");
        File p2=new File("damas/res/pe2.png");
        
        lb.setGraphic(new ImageView(ib.getPath()));
        lb1.setGraphic(new ImageView(p1.getPath()));
        lb1.getProperties().put("p", "cp1");
        lb2.setGraphic(new ImageView(ib.getPath()));
        lb3.setGraphic(new ImageView(p1.getPath()));
        lb3.getProperties().put("p", "cp1");
        lb4.setGraphic(new ImageView(ib.getPath()));
        lb5.setGraphic(new ImageView(p1.getPath()));
        lb5.getProperties().put("p", "cp1");
        
        lb6.setGraphic(new ImageView(p1.getPath()));
        lb6.getProperties().put("p", "cp1");
        lb7.setGraphic(new ImageView(ib.getPath()));
        lb8.setGraphic(new ImageView(p1.getPath()));
        lb8.getProperties().put("p", "cp1");
        lb9.setGraphic(new ImageView(ib.getPath()));
        lb10.setGraphic(new ImageView(p1.getPath()));;
        lb10.getProperties().put("p", "cp1");
        lb11.setGraphic(new ImageView(ib.getPath()));
        
        lb12.setGraphic(new ImageView(ib.getPath()));
        lb13.setGraphic(new ImageView(p1.getPath()));
        lb13.getProperties().put("p", "cp1");
        lb14.setGraphic(new ImageView(ib.getPath()));
        lb15.setGraphic(new ImageView(p1.getPath()));
        lb15.getProperties().put("p", "cp1");
        lb16.setGraphic(new ImageView(ib.getPath()));
        lb17.setGraphic(new ImageView(p1.getPath()));
        lb17.getProperties().put("p", "cp1");
        
        lb18.setGraphic(new ImageView(ic.getPath()));
        lb18.getProperties().put("p", "sp");
        lb19.setGraphic(new ImageView(ib.getPath()));
        lb20.setGraphic(new ImageView(ic.getPath()));
        lb20.getProperties().put("p", "sp");
        lb21.setGraphic(new ImageView(ib.getPath()));
        lb22.setGraphic(new ImageView(ic.getPath()));
        lb22.getProperties().put("p", "sp");
        lb23.setGraphic(new ImageView(ib.getPath()));
        
        lb24.setGraphic(new ImageView(ib.getPath()));
        lb25.setGraphic(new ImageView(ic.getPath()));
        lb25.getProperties().put("p", "sp");
        lb26.setGraphic(new ImageView(ib.getPath()));
        lb27.setGraphic(new ImageView(ic.getPath()));
        lb27.getProperties().put("p", "sp");
        lb28.setGraphic(new ImageView(ib.getPath()));
        lb29.setGraphic(new ImageView(ic.getPath()));
        lb29.getProperties().put("p", "sp");
        
        lb30.setGraphic(new ImageView(p2.getPath()));
        lb30.getProperties().put("p", "cp2");
        lb31.setGraphic(new ImageView(ib.getPath()));
        lb32.setGraphic(new ImageView(p2.getPath()));
        lb32.getProperties().put("p", "cp2");
        lb33.setGraphic(new ImageView(ib.getPath()));
        lb34.setGraphic(new ImageView(p2.getPath()));
        lb34.getProperties().put("p", "cp2");
        lb35.setGraphic(new ImageView(ib.getPath()));
        
        lb36.setGraphic(new ImageView(ib.getPath()));
        lb37.setGraphic(new ImageView(p2.getPath()));
        lb37.getProperties().put("p", "cp2");
        lb38.setGraphic(new ImageView(ib.getPath()));
        lb39.setGraphic(new ImageView(p2.getPath()));
        lb39.getProperties().put("p", "cp2");
        lb40.setGraphic(new ImageView(ib.getPath()));
        lb41.setGraphic(new ImageView(p2.getPath()));
        lb41.getProperties().put("p", "cp2");
        
        lb42.setGraphic(new ImageView(p2.getPath()));
        lb42.getProperties().put("p", "cp2");
        lb43.setGraphic(new ImageView(ib.getPath()));
        lb44.setGraphic(new ImageView(p2.getPath()));
        lb44.getProperties().put("p", "cp2");
        lb45.setGraphic(new ImageView(ib.getPath()));
        lb46.setGraphic(new ImageView(p2.getPath()));
        lb46.getProperties().put("p", "cp2");
        lb47.setGraphic(new ImageView(ib.getPath()));
        
        ADM adm=new ADM(dt,ic);
        
        lb.setId("bt1");
        lb1.setId("bt3");
        lb2.setId("bt1");
        lb3.setId("bt3");
        lb4.setId("bt1");
        lb5.setId("bt3");
        
        lb6.setId("bt3");
        lb7.setId("bt1");
        lb8.setId("bt3");
        lb9.setId("bt1");
        lb10.setId("bt3");
        lb11.setId("bt1");
        
        lb12.setId("bt1");
        lb13.setId("bt3");
        lb14.setId("bt1");
        lb15.setId("bt3");
        lb16.setId("bt1");
        lb17.setId("bt3");
        
        lb18.setId("bt3");
        lb19.setId("bt1");
        lb20.setId("bt3");
        lb21.setId("bt1");
        lb22.setId("bt3");
        lb23.setId("bt1");
        
        lb24.setId("bt1");
        lb25.setId("bt3");
        lb26.setId("bt1");
        lb27.setId("bt3");
        lb28.setId("bt1");
        lb29.setId("bt3");
        
        lb30.setId("bt3");
        lb31.setId("bt1");
        lb32.setId("bt3");
        lb33.setId("bt1");
        lb34.setId("bt3");
        lb35.setId("bt1");
        
        lb36.setId("bt1");
        lb37.setId("bt3");
        lb38.setId("bt1");
        lb39.setId("bt3");
        lb40.setId("bt1");
        lb41.setId("bt3");
        
        lb42.setId("bt3");
        lb43.setId("bt1");
        lb44.setId("bt3");
        lb45.setId("bt1");
        lb46.setId("bt3");
        lb47.setId("bt1");
        
        pn.add(lb,0,0);
        pn.add(lb1,1,0);
        pn.add(lb2,2,0);
        pn.add(lb3,3,0);
        pn.add(lb4,4,0);
        pn.add(lb5,5,0);
        pn.add(lb6,0,1);
        pn.add(lb7,1,1);
        pn.add(lb8,2,1);
        pn.add(lb9,3,1);
        pn.add(lb10,4,1);
        pn.add(lb11,5,1);
        pn.add(lb12,0,3);
        pn.add(lb13,1,3);
        pn.add(lb14,2,3);
        pn.add(lb15,3,3);
        pn.add(lb16,4,3);
        pn.add(lb17,5,3);
        pn.add(lb18,0,4);
        pn.add(lb19,1,4);
        pn.add(lb20,2,4);
        pn.add(lb21,3,4);
        pn.add(lb22,4,4);
        pn.add(lb23,5,4);
        pn.add(lb24,0,5);
        pn.add(lb25,1,5);
        pn.add(lb26,2,5);
        pn.add(lb27,3,5);
        pn.add(lb28,4,5);
        pn.add(lb29,5,5);
        pn.add(lb30,0,6);
        pn.add(lb31,1,6);
        pn.add(lb32,2,6);
        pn.add(lb33,3,6);
        pn.add(lb34,4,6);
        pn.add(lb35,5,6);
        pn.add(lb36,0,7);
        pn.add(lb37,1,7);
        pn.add(lb38,2,7);
        pn.add(lb39,3,7);
        pn.add(lb40,4,7);
        pn.add(lb41,5,7);
        pn.add(lb42,0,8);
        pn.add(lb43,1,8);
        pn.add(lb44,2,8);
        pn.add(lb45,3,8);
        pn.add(lb46,4,8);
        pn.add(lb47,5,8);
        
        
        
        pn.setOnMousePressed(e ->{
            double clickx=e.getSceneX();
            double clicky=e.getSceneY();
            Label l=dt.clickXY(clickx, clicky);
            String i=l.getId();
            if(e.getButton()==e.getButton().PRIMARY){
                if(i.equals("bt1")){
                    l.setId("bt2");
                }else if (i.equals("bt2")){
                    l.setId("bt1");
                }else if (i.equals("bt3")){
                    l.setId("bt4");
                    adm.trocar(e.getSceneX(), e.getSceneY());
                }else if (i.equals("bt4")){
                    l.setId("bt3");
                    adm.trocar(e.getSceneX(), e.getSceneY());
                }else if(i.equals("btGG")){
                    l.setId("bt4");
                }else if(i.equals("btG")){
                    l.setId("bt2");
                }else if(i.equals("btsel")){
                    adm.trocar(e.getSceneX(), e.getSceneY());
                }
            }else{
                if(i.equals("bt1")){
                    l.setId("btG");
                }else if (i.equals("btG")){
                    l.setId("bt1");
                }else if (i.equals("bt3")){
                    l.setId("btGG");
                }else if (i.equals("btGG")){
                    l.setId("bt3");
                }else if(i.equals("bt4")){
                    l.setId("btGG");
                }else if(i.equals("bt2")){
                    l.setId("btG");
                }
            }
        });
    }
    public Scene getCena(){
        return a;
    }
}
